package com.zavan.dedesite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DedesiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(DedesiteApplication.class, args);
	}

}
